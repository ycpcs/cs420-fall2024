#ifndef _sem_name_h
#define _sem_name_h

const char* SEM_NAME = // "YOUR_YCP_USERNAME";

#endif

