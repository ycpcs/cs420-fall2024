#ifndef _utils_h
#define _utils_h


FILE* open_file(char* filename, char* rw);
void close_file(FILE* fp);

#endif

